import setuptools

setuptools.setup(
    name='lenticular_lenses',
    version='1.0',
    packages=setuptools.find_packages(),
)
